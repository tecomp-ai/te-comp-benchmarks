/* Token sampler — argmax or temperature-based sampling.
 *
 * Baremetal-friendly: no malloc, fixed-size top-k buffer, xorshift64 RNG.
 */

#ifndef SAMPLER_H
#define SAMPLER_H

#include <stdint.h>

typedef struct {
    float temperature;      /* 0.0 = argmax, >0 = softmax + multinomial */
    float top_p;            /* Nucleus sampling threshold (0.0-1.0, 0=disabled) */
    uint64_t rng_state;     /* xorshift64* state */
} sampler_t;

/* Initialize sampler with temperature and RNG seed. */
void sampler_init(sampler_t *s, float temperature, float top_p, uint64_t seed);

/* Sample a token from logits[0..vocab_size-1].
 * Returns the selected token index. */
int sampler_sample(sampler_t *s, const float *logits, int vocab_size);

/* Pure argmax (no RNG needed). */
int sampler_argmax(const float *logits, int vocab_size);

#endif /* SAMPLER_H */
