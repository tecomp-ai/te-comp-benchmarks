/* CTK2 BPE tokenizer — baremetal, zero malloc.
 *
 * Encode: byte-level BPE with greedy merge (lowest result ID wins).
 * Decode: piece table lookup (linear walk or O(1) with offset table).
 *
 * Follows cardputer-ai/main/llm.cpp ctk2_* functions.
 */

#include "tokenizer.h"
#include <string.h>

#define CTK2_MAGIC  0x324B5443UL  /* "CTK2" little-endian */

/* -----------------------------------------------------------------------
 * Init — parse CTK2 blob header, set up pointers
 * ----------------------------------------------------------------------- */
int tokenizer_init(tokenizer_t *tk, const uint8_t *blob, uint32_t blob_size) {
    if (blob_size < 20) return -1;

    /* Check magic */
    uint32_t magic;
    memcpy(&magic, blob, 4);
    if (magic != CTK2_MAGIC) return -1;

    /* Parse header */
    memcpy(&tk->vocab_size,       blob +  4, 4);
    memcpy(&tk->max_token_length, blob +  8, 4);
    memcpy(&tk->eos_id,           blob + 12, 4);
    memcpy(&tk->n_merges,         blob + 16, 4);

    /* byte_ids[256] starts at offset 20 */
    tk->byte_ids = (const uint16_t *)(blob + 20);

    /* merges[n_merges][3] starts after byte_ids */
    tk->merges = (const uint16_t *)(blob + 20 + 256 * 2);

    /* pieces start after merges */
    tk->pieces = blob + 20 + 256 * 2 + (uint32_t)tk->n_merges * 6;

    tk->piece_offsets = NULL;

    return 0;
}

/* -----------------------------------------------------------------------
 * Build offset table for O(1) decode
 * ----------------------------------------------------------------------- */
void tokenizer_build_offsets(const tokenizer_t *tk, uint32_t *buf) {
    const uint8_t *p = tk->pieces;
    for (int i = 0; i < tk->vocab_size; i++) {
        buf[i] = (uint32_t)(p - tk->pieces);
        int32_t len;
        memcpy(&len, p, 4);
        p += 4 + len;
    }
}

/* -----------------------------------------------------------------------
 * Merge lookup — binary search in sorted (a, b, result) triples
 * ----------------------------------------------------------------------- */
static int ctk2_find_merge(const tokenizer_t *tk, uint16_t a, uint16_t b) {
    /* merges are sorted by (a, b). Each entry is 3 x uint16_t. */
    int lo = 0, hi = tk->n_merges - 1;
    uint32_t key = ((uint32_t)a << 16) | b;

    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        const uint16_t *m = tk->merges + mid * 3;
        uint32_t mkey = ((uint32_t)m[0] << 16) | m[1];
        if (mkey == key) {
            return (int)m[2];  /* result token ID */
        } else if (mkey < key) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;  /* no merge found */
}

/* -----------------------------------------------------------------------
 * Encode — byte-level BPE
 * ----------------------------------------------------------------------- */
int tokenizer_encode(const tokenizer_t *tk, const char *text,
                     uint16_t *out_tokens, int max_tokens) {
    int n = 0;

    /* Step 1: map each byte to its base token */
    for (const unsigned char *c = (const unsigned char *)text; *c; c++) {
        if (n >= max_tokens) break;
        out_tokens[n++] = tk->byte_ids[*c];
    }

    /* Step 2: greedily merge adjacent pairs (lowest result ID wins) */
    while (n > 1) {
        int best_c = -1;
        int best_idx = -1;

        for (int i = 0; i < n - 1; i++) {
            int c = ctk2_find_merge(tk, out_tokens[i], out_tokens[i + 1]);
            if (c >= 0 && (best_c < 0 || c < best_c)) {
                best_c = c;
                best_idx = i;
            }
        }

        if (best_idx < 0) break;

        /* Apply merge: replace pair with merged token, shift rest left */
        out_tokens[best_idx] = (uint16_t)best_c;
        for (int i = best_idx + 1; i < n - 1; i++) {
            out_tokens[i] = out_tokens[i + 1];
        }
        n--;
    }

    return n;
}

/* -----------------------------------------------------------------------
 * Decode — token ID to string piece
 * ----------------------------------------------------------------------- */
const char *tokenizer_decode(const tokenizer_t *tk, uint16_t token,
                             char *scratch, int scratch_size) {
    if (token == (uint16_t)tk->eos_id) {
        scratch[0] = '\0';
        return scratch;
    }

    if (token >= (uint16_t)tk->vocab_size) {
        scratch[0] = '?';
        scratch[1] = '\0';
        return scratch;
    }

    const uint8_t *p;

    if (tk->piece_offsets) {
        /* O(1) lookup */
        p = tk->pieces + tk->piece_offsets[token];
    } else {
        /* Linear walk (slow but works without offset table) */
        p = tk->pieces;
        for (int i = 0; i < (int)token; i++) {
            int32_t len;
            memcpy(&len, p, 4);
            p += 4 + len;
        }
    }

    int32_t len;
    memcpy(&len, p, 4);
    p += 4;

    if (len >= scratch_size) len = scratch_size - 1;
    memcpy(scratch, p, len);
    scratch[len] = '\0';

    return scratch;
}
