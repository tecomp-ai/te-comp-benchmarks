/*==================================================================================================
* Project : RTD AUTOSAR 4.7
* Platform : CORTEXM
* Peripheral : S32K3XX
* Dependencies : none
*
* Autosar Version : 4.7.0
* Autosar Revision : ASR_REL_4_7_REV_0000
* Autosar Conf.Variant :
* SW Version : 6.0.0
* Build Version : S32K3_RTD_6_0_0_D2506_ASR_REL_4_7_REV_0000_20250610
*
* Copyright 2020 - 2025 NXP
*
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be 
*   used strictly in accordance with the applicable license terms.  By expressly 
*   accepting such terms or by downloading, installing, activating and/or otherwise 
*   using the software, you are agreeing that you have read, and that you agree to 
*   comply with and are bound by, such license terms.  If you do not agree to be 
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file main.c
*
*   @addtogroup main_module main module documentation
*   @{
*/

/* Including necessary configuration files. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* User includes */
#include "OsIf.h"

#include "bsp.h"
#include "tokenizer.h"
#include "sampler.h"
#include "inference_api.h"


/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */
#define REG_COREDEBUG_DEMCR (*(volatile uint32_t *)0xE000EDFCU)
#define REG_DWT_CTRL        (*(volatile uint32_t *)0xE0001000U)
#define REG_DWT_CYCCNT      (*(volatile uint32_t *)0xE0001004U)
#define REG_DWT_LAR         (*(volatile uint32_t *)0xE0001FB0U)
#define REG_DWT_LSR         (*(volatile uint32_t *)0xE0001FB4U)

#define UART_TIMEOUT		50000

#define MAX_PROMPT_LEN  	256       /* Max prompt text length (bytes) */
#define MAX_GEN_TOKENS  	256       /* Max tokens to generate per turn */
#define TEMPERATURE     	0.8f      /* Sampling temperature (0=argmax) */
#define TOP_P           	0.9f      /* Nucleus sampling threshold */

/* Vocab size from the pruned model */
#define VOCAB_SIZE      	14632

/* Prompt modes — match cardputer-ai's fine-tune format */
#define MODE_CHAT   		0   /* "User: <text>\nBot:" — conversational */
#define MODE_STORY  		1   /* "Summary: <text>\nStory:" — story generation */
#define MODE_RAW    		2   /* plain text completion */
#define DEFAULT_MODE 		MODE_STORY

/* -----------------------------------------------------------------------
 * External data — linked from tok_data.c and vocab_remap.c
 * ----------------------------------------------------------------------- */
extern const uint8_t  		TOKENIZER_DATA[];
extern const uint32_t 		TOKENIZER_DATA_SIZE;

/* Pruned ID -> Original GPT-2 ID lookup table.
 * te-comp engine has an internal re-map table and expects original GPT-2 IDs. */
extern const int32_t 		PRUNED_TO_ORIG[];
extern const int32_t 		PRUNED_TO_ORIG_SIZE;

/* -----------------------------------------------------------------------
 * Globals
 * ----------------------------------------------------------------------- */
static tokenizer_t 			tokenizer;
static sampler_t   			sampler;
static int         			prompt_mode = DEFAULT_MODE;

/* Piece offset table for O(1) decode — allocated in BSS.
 * vocab_size * 4 bytes = 14639 * 4 = ~57 KB. */
__attribute__((section(".dtcm_bss")))
static uint32_t 			piece_offset_buf[16384];

/* Prompt token buffer — enlarged for wrapped prompts */
static uint16_t 			prompt_tokens[TOK_MAX_TOKENS * 2];

/* Decode scratch buffer */
static char 				decode_scratch[128];

/* Prompt text buffer */
static char 				prompt_buf[MAX_PROMPT_LEN];

/* Wrapped prompt buffer (for chat/story mode) */
static char 				wrapped_buf[MAX_PROMPT_LEN + 64];

/* Buffer for status message */
static char 				status_buffer[MAX_PROMPT_LEN];

/* single-byte landing pad the driver writes into */
static uint8_t 				rx_char;

volatile uint32_t 			seed_cycles = 0;


/* -----------------------------------------------------------------------
 * HW cycle counter initialization
 * ----------------------------------------------------------------------- */
static void InitHWCycleCounter(void) {
    /* Enable Global Trace and Debug Block (DEMCR -> TRCENA bit 24) */
    REG_COREDEBUG_DEMCR |= (1U << 24);

    /* Unlock the DWT Unit (Required for Cortex-M7 cores like S32K3)
     * If the Software Lock Status (LSR bit 1) is active, write the unlock key to LAR
     */
    if ((REG_DWT_LSR & 0x2U) != 0U) {
        REG_DWT_LAR = 0xC5ACCE55U;
    }

    /* Clear the cycle counter and flip the enable bit (CTRL -> CYCCNTENA bit 0) */
    REG_DWT_CYCCNT = 0U;
    REG_DWT_CTRL  |= (1U << 0);
}

/* -----------------------------------------------------------------------
 * Banner
 * ----------------------------------------------------------------------- */
static const char* ModeName(int m) {
    switch (m) {
        case MODE_CHAT:  return "Chat (User/Bot)";
        case MODE_STORY: return "Story (Summary/Story)";
        default:         return "Raw Completion";
    }
}

/* -----------------------------------------------------------------------
 * Print tiny story banner
 * ----------------------------------------------------------------------- */
static void PrintBanner(void) {
    const inference_info_t *info = inference_get_info();

    int msg_len = snprintf(status_buffer, sizeof(status_buffer), "TinyStories-v2 (te-comp, S32K3x4EVB-T172)\r\n");
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "Type a prompt, press Enter.\r\n");
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "Empty line = quit.\r\n");
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "/chat /story /raw = switch mode\r\n");
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "Model: %s\r\n", info->model_name);
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "Arena: %luB, Weights: %luB\r\n", info->arena_size_bytes, info->weights_flash_bytes);
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "Mode: %s\r\n", ModeName(prompt_mode));
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
}

/* -----------------------------------------------------------------------
 * Run one generation turn
 * ----------------------------------------------------------------------- */
static void GenerateAnswer(const char *prompt_text) {
	int msg_len = 0;
    /* Wrap prompt according to mode (matches cardputer-ai fine-tune format) */
    const char *text_to_encode = prompt_text;
    if (prompt_mode == MODE_CHAT) {
        snprintf(wrapped_buf, sizeof(wrapped_buf), "User: %s\nBot:", prompt_text);
        text_to_encode = wrapped_buf;
    } else if (prompt_mode == MODE_STORY) {
        snprintf(wrapped_buf, sizeof(wrapped_buf), "Summary: %s\nStory:", prompt_text);
        text_to_encode = wrapped_buf;
    }

    /* Encode prompt */
    int n_prompt = tokenizer_encode(&tokenizer, text_to_encode, prompt_tokens, TOK_MAX_TOKENS * 2);
    if (n_prompt <= 0) {
    	msg_len = snprintf(status_buffer, sizeof(status_buffer), "[ERROR Empty prompt after tokenization]\r\n");
    	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
        return;
    }

    msg_len = snprintf(status_buffer, sizeof(status_buffer), "[PROMPT %d tokens, generating...]\r\n", n_prompt);
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

    /* Re-init engine for each generation turn (resets KV cache) */
    inference_init(NULL);

    int pos = 0;
    int token = prompt_tokens[0];
    int gen_count = 0;
    uint32_t max_token_time_ms = 0;
    uint32_t min_token_time_ms = (1 << 31);

    /* Token-by-token loop: pre-fill + decode */
    for (int step = 0; step < n_prompt + MAX_GEN_TOKENS - 1; step++) {
    	/* Set input token via inference API.
         * The tokenizer produces pruned IDs (0..VOCAB_SIZE-1), but the
         * te-comp engine expects original GPT-2 IDs (has internal re-map). */
        int64_t *input = inference_get_input();
        int orig_id = (token >= 0 && token < PRUNED_TO_ORIG_SIZE) ? PRUNED_TO_ORIG[token] : token;
        *input = (int64_t)orig_id;

        /* Run one forward pass */
    	__asm volatile("dsb\n isb");
    	uint32_t start_cycles = REG_DWT_CYCCNT;
    	__asm volatile("dsb\n isb");
        inference_run();
        __asm volatile("dsb\n isb");
        uint32_t end_cycles = REG_DWT_CYCCNT;
        __asm volatile("dsb\n isb");
        uint32_t delta_cycles_ms = (end_cycles - start_cycles) / 160000;
        max_token_time_ms = (delta_cycles_ms > max_token_time_ms) ? delta_cycles_ms : max_token_time_ms;
        min_token_time_ms = (delta_cycles_ms < min_token_time_ms) ? delta_cycles_ms : min_token_time_ms;

        /* Get output logits via inference API */
        const float *logits = inference_get_output();

        int next;
        if (pos < n_prompt - 1) {
            /* Pre-fill: force next prompt token */
            next = prompt_tokens[pos + 1];
        } else {
            /* Decode: sample from logits */
            next = sampler_sample(&sampler, logits, VOCAB_SIZE);
            gen_count++;

            /* Check EOS */
            if (next == tokenizer.eos_id) {
            	msg_len = snprintf(status_buffer, sizeof(status_buffer), "\r\n[EOS After %d tokens]\r\n", gen_count);
            	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
                break;
            }

            /* Decode and print token */
            const char *piece = tokenizer_decode(&tokenizer, (uint16_t)next, decode_scratch, sizeof(decode_scratch));

            /* In chat mode, stop if model starts a new "User:" turn */
            if (prompt_mode == MODE_CHAT && piece &&
                strncmp(piece, "User", 4) == 0) {
            	msg_len = snprintf(status_buffer, sizeof(status_buffer), "\r\n[TURN End after %d tokens]\r\n", gen_count);
            	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
                break;
            }

            msg_len = snprintf(status_buffer, sizeof(status_buffer), "%s", piece);
            Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
        }

        token = next;
        pos++;

        /* Safety limit */
        if (gen_count >= MAX_GEN_TOKENS) {
            break;
        }
    }

    /* Report inference time */
    msg_len = snprintf(status_buffer, sizeof(status_buffer), "\r\n[TIME min: %lums/token, max: %lums/token]\r\n", (unsigned long)min_token_time_ms, (unsigned long)max_token_time_ms);
    Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
}

/* -----------------------------------------------------------------------
 * Entry point
 * ----------------------------------------------------------------------- */
int main(void) {
	int msg_len = 0;
	uint16 rxIndex = 0U;
	Lpuart_Uart_Ip_StatusType status = LPUART_UART_IP_STATUS_SUCCESS;

	/* Initialize board */
	Bsp_Init_StatusType Bsp_Init_Status = Bsp_Init();
	if (Bsp_Init_Status != BSP_INIT_SUCCESS){
		while(1);
	}

	/* Init HW cycle counter */
	InitHWCycleCounter();

	/* Initialize inference engine */
	if (inference_init(NULL) != 0) {
		msg_len = snprintf(status_buffer, sizeof(status_buffer), "[ERROR] inference_init failed\r\n");
		Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
		goto EXIT;
	}

	msg_len = snprintf(status_buffer, sizeof(status_buffer), "[BOOT] Engine OK\r\n");
	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

	/* Tokenizer — placeholder blob will fail, skip gracefully */
	int tok_ok = tokenizer_init(&tokenizer, TOKENIZER_DATA, TOKENIZER_DATA_SIZE);
	if (tok_ok != 0 || tokenizer.vocab_size == 0) {
		msg_len = snprintf(status_buffer, sizeof(status_buffer), "[WARN] Tokenizer not loaded\r\n");
		Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
		goto EXIT;
	}

	msg_len = snprintf(status_buffer, sizeof(status_buffer), "[BOOT] Tokenizer OK\r\n");
	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

	/* Build piece offset table for O(1) decode */
	if (tokenizer.vocab_size > 0 &&
		tokenizer.vocab_size <= (int)(sizeof(piece_offset_buf) / sizeof(piece_offset_buf[0]))) {
		tokenizer_build_offsets(&tokenizer, piece_offset_buf);
		tokenizer.piece_offsets = piece_offset_buf;
	}

	/* Seed RNG from DWT cycle counter at user key press */
	msg_len = snprintf(status_buffer, sizeof(status_buffer), "[BOOT] Press any key to start...\r\n");
	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);

	while (1) {
		status = Lpuart_Uart_Ip_SyncReceive(UART_INSTANCE, &rx_char, 1U, UART_TIMEOUT);
		if (status == LPUART_UART_IP_STATUS_SUCCESS){
			__asm volatile("dsb\n isb");
			seed_cycles = REG_DWT_CYCCNT;
			__asm volatile("dsb\n isb");
			break;
		}
	}

	/* Mix the cycle count for better bit distribution */
	msg_len = snprintf(status_buffer, sizeof(status_buffer), "[BOOT] Sampler seed: %lu\r\n", seed_cycles);
	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
	uint64_t seed = (uint64_t)seed_cycles * 0x2545F4914F6CDD1DULL;
	seed ^= (uint64_t)(seed_cycles >> 16) * 0x9E3779B97F4A7C15ULL;
	sampler_init(&sampler, TEMPERATURE, TOP_P, seed);

	/* Print banner */
	PrintBanner();

	/* Interactive loop */
	Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)"Prompt> ", 8U, UART_TIMEOUT);
	while (1) {
		status = Lpuart_Uart_Ip_SyncReceive(UART_INSTANCE, &rx_char, 1U, UART_TIMEOUT);
		if (status == LPUART_UART_IP_STATUS_SUCCESS){
			if (rx_char == '\n' || rx_char == '\r') {
				Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)"\r\n", 2U, UART_TIMEOUT);
				if (rxIndex > 0U) {
					prompt_buf[rxIndex] = '\0';
					/* Mode switching commands */
					if (strcmp(prompt_buf, "/chat") == 0) {
						prompt_mode = MODE_CHAT;
						msg_len = snprintf(status_buffer, sizeof(status_buffer), "Mode: %s\r\n", ModeName(prompt_mode));
						Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
					} else if (strcmp(prompt_buf, "/story") == 0) {
						prompt_mode = MODE_STORY;
						msg_len = snprintf(status_buffer, sizeof(status_buffer), "Mode: %s\r\n", ModeName(prompt_mode));
						Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
					} else if (strcmp(prompt_buf, "/raw") == 0) {
						prompt_mode = MODE_RAW;
						msg_len = snprintf(status_buffer, sizeof(status_buffer), "Mode: %s\r\n", ModeName(prompt_mode));
						Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)status_buffer, msg_len, UART_TIMEOUT);
					}
					else {
						/* Generate answer */
						GenerateAnswer(prompt_buf);
					}

					rxIndex = 0;
					Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)"Prompt> ", 8U, UART_TIMEOUT);
				}
				else {
					Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)"[Bye]\r\n", 7U, UART_TIMEOUT);
					break;
				}
			}
			else if (rx_char == '\b' || rx_char == 0x7F) {
				if (rxIndex > 0U) {
					rxIndex--;
					Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, (const uint8_t*)"\b \b", 3U, UART_TIMEOUT);
				}
			}
			else {
				/* it is printable character */
				if (rx_char >= 0x20U && rx_char < 0x7FU && rxIndex < (MAX_PROMPT_LEN - 1U)) {
					prompt_buf[rxIndex] = rx_char;
					rxIndex++;
					Lpuart_Uart_Ip_SyncSend(UART_INSTANCE, &rx_char, 1U, UART_TIMEOUT);
				}
			}
		}
	}

EXIT:
	/* Deinit board */
	Bsp_Deinit();

    for ( ;; );

    return 0;
}

/** @} */
