/* Token sampler — baremetal, zero malloc.
 *
 * Follows cardputer-ai/llm.cpp sampler pattern:
 *   - Argmax at temperature=0
 *   - Temperature scaling + softmax + multinomial sampling otherwise
 *   - Optional top-p (nucleus) filtering
 *   - xorshift64* RNG (no stdlib dependency)
 */

#include "sampler.h"
#include <math.h>

/* -----------------------------------------------------------------------
 * xorshift64* RNG — same as cardputer-ai
 * ----------------------------------------------------------------------- */
static uint32_t rng_u32(sampler_t *s) {
    uint64_t x = s->rng_state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    s->rng_state = x;
    return (uint32_t)((x * 0x2545F4914F6CDD1DULL) >> 32);
}

static float rng_float(sampler_t *s) {
    return (float)(rng_u32(s) >> 8) / 16777216.0f;  /* [0, 1) */
}

/* -----------------------------------------------------------------------
 * Init
 * ----------------------------------------------------------------------- */
void sampler_init(sampler_t *s, float temperature, float top_p, uint64_t seed) {
    s->temperature = temperature;
    s->top_p = top_p;
    s->rng_state = seed ? seed : 0xDEADBEEFCAFEULL;
}

/* -----------------------------------------------------------------------
 * Argmax
 * ----------------------------------------------------------------------- */
int sampler_argmax(const float *logits, int vocab_size) {
    int best = 0;
    float best_val = logits[0];
    for (int i = 1; i < vocab_size; i++) {
        if (logits[i] > best_val) {
            best_val = logits[i];
            best = i;
        }
    }
    return best;
}

/* -----------------------------------------------------------------------
 * Sample with temperature + optional top-p
 * ----------------------------------------------------------------------- */

/* Small fixed-size buffer for top-p candidates */
#define TOP_K_BUF  64

typedef struct {
    float prob;
    int   index;
} candidate_t;

int sampler_sample(sampler_t *s, const float *logits, int vocab_size) {
    if (s->temperature <= 0.0f) {
        return sampler_argmax(logits, vocab_size);
    }

    /* Temperature scaling + find max for numerical stability */
    float inv_temp = 1.0f / s->temperature;
    float max_logit = logits[0];
    for (int i = 1; i < vocab_size; i++) {
        if (logits[i] > max_logit) max_logit = logits[i];
    }

    /* Softmax with top-k pre-filter:
     * Track the TOP_K_BUF highest logits to avoid computing exp()
     * for all vocab_size entries (saves ~10ms at vocab=14639). */
    candidate_t top[TOP_K_BUF];
    int n_top = 0;
    float sum = 0.0f;

    for (int i = 0; i < vocab_size; i++) {
        float p = expf((logits[i] - max_logit) * inv_temp);

        if (n_top < TOP_K_BUF) {
            top[n_top].prob = p;
            top[n_top].index = i;
            n_top++;
            sum += p;
        } else {
            /* Find minimum in top buffer */
            int min_idx = 0;
            float min_val = top[0].prob;
            for (int j = 1; j < TOP_K_BUF; j++) {
                if (top[j].prob < min_val) {
                    min_val = top[j].prob;
                    min_idx = j;
                }
            }
            if (p > min_val) {
                sum -= top[min_idx].prob;
                top[min_idx].prob = p;
                top[min_idx].index = i;
                sum += p;
            }
        }
    }

    /* Normalize */
    if (sum > 0.0f) {
        float inv_sum = 1.0f / sum;
        for (int i = 0; i < n_top; i++) {
            top[i].prob *= inv_sum;
        }
    }

    /* Top-p (nucleus) filtering */
    if (s->top_p > 0.0f && s->top_p < 1.0f) {
        /* Sort descending by probability (insertion sort, small array) */
        for (int i = 1; i < n_top; i++) {
            candidate_t key = top[i];
            int j = i - 1;
            while (j >= 0 && top[j].prob < key.prob) {
                top[j + 1] = top[j];
                j--;
            }
            top[j + 1] = key;
        }

        /* Find cutoff */
        float cumsum = 0.0f;
        int cutoff = n_top;
        for (int i = 0; i < n_top; i++) {
            cumsum += top[i].prob;
            if (cumsum >= s->top_p) {
                cutoff = i + 1;
                break;
            }
        }
        n_top = cutoff;

        /* Re-normalize */
        sum = 0.0f;
        for (int i = 0; i < n_top; i++) sum += top[i].prob;
        if (sum > 0.0f) {
            float inv_sum = 1.0f / sum;
            for (int i = 0; i < n_top; i++) top[i].prob *= inv_sum;
        }
    }

    /* Multinomial sampling */
    float r = rng_float(s);
    float cumsum = 0.0f;
    for (int i = 0; i < n_top; i++) {
        cumsum += top[i].prob;
        if (r < cumsum) {
            return top[i].index;
        }
    }

    /* Fallback (rounding) */
    return top[n_top - 1].index;
}
