/* Minimal GPT-2 BPE tokenizer for baremetal — CTK2 blob format.
 *
 * Compatible with cardputer-ai's convert_tinystories_instruct.py output.
 * Zero malloc: all pointers point into the flash-resident CTK2 blob.
 *
 * CTK2 blob layout:
 *   [u32 magic = 0x324B5443 "CTK2"]
 *   [i32 vocab_size]
 *   [i32 max_token_length]
 *   [i32 eos_id]
 *   [i32 n_merges]
 *   [u16 byte_ids[256]]        -- byte value -> token id
 *   [u16 merges[n_merges][3]]  -- (a, b, result) triples, sorted by (a,b)
 *   [pieces...]                -- vocab_size records of [i32 len][bytes]
 */

#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <stdint.h>

#define TOK_MAX_TOKENS  512   /* Max tokens in a single encode call */

typedef struct {
    int32_t  vocab_size;
    int32_t  max_token_length;
    int32_t  eos_id;
    int32_t  n_merges;

    const uint16_t *byte_ids;       /* [256] byte -> token id */
    const uint16_t *merges;         /* [n_merges][3] (a, b, result) */
    const uint8_t  *pieces;         /* vocab_size records of [i32 len][bytes] */

    /* Precomputed piece offset table for O(1) decode (optional).
     * If NULL, decode walks pieces linearly (slow but works). */
    const uint32_t *piece_offsets;  /* [vocab_size] byte offset into pieces */
} tokenizer_t;

/* Initialize tokenizer from a CTK2 blob in flash.
 * Returns 0 on success, -1 on invalid magic/format. */
int tokenizer_init(tokenizer_t *tk, const uint8_t *blob, uint32_t blob_size);

/* Build piece_offsets table for O(1) decode.
 * Writes vocab_size uint32_t entries into the provided buffer.
 * The buffer must be at least vocab_size * 4 bytes.
 * After this call, set tk->piece_offsets = buf. */
void tokenizer_build_offsets(const tokenizer_t *tk, uint32_t *buf);

/* Encode text into token IDs. Returns number of tokens.
 * out_tokens must have space for at least TOK_MAX_TOKENS entries. */
int tokenizer_encode(const tokenizer_t *tk, const char *text,
                     uint16_t *out_tokens, int max_tokens);

/* Decode a single token ID to a string.
 * Writes into scratch buffer (must be >= max_token_length + 1 bytes).
 * Returns pointer to scratch (NUL-terminated), or "" for EOS. */
const char *tokenizer_decode(const tokenizer_t *tk, uint16_t token,
                             char *scratch, int scratch_size);

/* Map between pruned (model) token IDs and original GPT-2 IDs.
 * These are needed if the te-comp engine uses pruned vocab but
 * the tokenizer blob uses original IDs.
 * The remap table is a simple array: remap[pruned_id] = original_id.
 * Set to NULL if vocab is not pruned. */
typedef struct {
    const uint16_t *to_original;   /* [pruned_vocab_size] */
    const uint16_t *to_pruned;     /* [original_vocab_size] (sparse, 0xFFFF = unmapped) */
    int pruned_vocab_size;
    int original_vocab_size;
} vocab_remap_t;

#endif /* TOKENIZER_H */
